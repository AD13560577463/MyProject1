/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 80032
Source Host           : localhost:3306
Source Database       : qtqq

Target Server Type    : MYSQL
Target Server Version : 80032
File Encoding         : 65001

Date: 2023-06-08 16:06:34
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `tab_accounts`
-- ----------------------------
DROP TABLE IF EXISTS `tab_accounts`;
CREATE TABLE `tab_accounts` (
  `employeeID` int NOT NULL COMMENT 'éƒ¨é—¨ID',
  `account` char(20) CHARACTER SET gbk COLLATE gbk_chinese_ci NOT NULL COMMENT 'å‘˜å·¥è´¦å·',
  `code` char(20) CHARACTER SET gbk COLLATE gbk_chinese_ci NOT NULL DEFAULT '' COMMENT 'è´¦å·çš„å¯†ç ',
  PRIMARY KEY (`account`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- ----------------------------
-- Records of tab_accounts
-- ----------------------------
INSERT INTO `tab_accounts` VALUES ('10002', 'rener', 'rener');
INSERT INTO `tab_accounts` VALUES ('10003', 'rensan', 'rensan');
INSERT INTO `tab_accounts` VALUES ('10001', 'renyi', 'renyi');
INSERT INTO `tab_accounts` VALUES ('10008', 'shier', 'shier');
INSERT INTO `tab_accounts` VALUES ('10009', 'shisan', 'shisan');
INSERT INTO `tab_accounts` VALUES ('10007', 'shiyi', 'shiyi');
INSERT INTO `tab_accounts` VALUES ('10005', 'yaner', 'yaner');
INSERT INTO `tab_accounts` VALUES ('10006', 'yansan', 'yansan');
INSERT INTO `tab_accounts` VALUES ('10004', 'yanyi', 'yanyi');
INSERT INTO `tab_accounts` VALUES ('10010', '叶舒华', 'yeshuhua');

-- ----------------------------
-- Table structure for `tab_department`
-- ----------------------------
DROP TABLE IF EXISTS `tab_department`;
CREATE TABLE `tab_department` (
  `departmentID` int NOT NULL AUTO_INCREMENT COMMENT '閮ㄩ棬宸ュ彿',
  `department_name` char(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '部门名字',
  `picture` char(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '部门照片',
  `sign` char(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '閮ㄩ棬鍙ｅ彿',
  PRIMARY KEY (`departmentID`)
) ENGINE=InnoDB AUTO_INCREMENT=2004 DEFAULT CHARSET=utf8mb3;

-- ----------------------------
-- Records of tab_department
-- ----------------------------
INSERT INTO `tab_department` VALUES ('2000', '公司群', 'E:\\qtqq_images\\gsq.png', '公司与各位一起进步');
INSERT INTO `tab_department` VALUES ('2001', '人事部', 'E:\\qtqq_images\\rsb.png', '欢迎加入公司一起奋斗');
INSERT INTO `tab_department` VALUES ('2002', '研发部', 'E:\\qtqq_images\\yfb.png', '编程语言就选c++');
INSERT INTO `tab_department` VALUES ('2003', '市场部', 'E:\\qtqq_images\\scb.png', '今天不努力，明天努力找工作');

-- ----------------------------
-- Table structure for `tab_employees`
-- ----------------------------
DROP TABLE IF EXISTS `tab_employees`;
CREATE TABLE `tab_employees` (
  `departmentID` int NOT NULL COMMENT '部门ID',
  `employeeID` int NOT NULL AUTO_INCREMENT COMMENT '鍛樺伐ID',
  `employee_name` char(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '员工名字',
  `employee_sign` char(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '员工签名',
  `status` tinyint NOT NULL DEFAULT '1',
  `picture` char(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '鍛樺伐鐓х墖',
  `online` int DEFAULT NULL COMMENT '1离线 2在线 3隐身',
  PRIMARY KEY (`employeeID`)
) ENGINE=InnoDB AUTO_INCREMENT=100002 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ----------------------------
-- Records of tab_employees
-- ----------------------------
INSERT INTO `tab_employees` VALUES ('2001', '10001', 'renyi', '肤白如雪就是我', '1', 'E:\\qtqq_images\\r1.png', '2');
INSERT INTO `tab_employees` VALUES ('2001', '10002', 'rener', '美丽的我', '1', 'E:\\qtqq_images\\r2.png', '2');
INSERT INTO `tab_employees` VALUES ('2001', '10003', 'rensan', '我就是你得不到的女人', '1', 'E:\\qtqq_images\\r3.png', '2');
INSERT INTO `tab_employees` VALUES ('2002', '10004', 'yanyi', '调bug中', '1', 'E:\\qtqq_images\\y1.png', '2');
INSERT INTO `tab_employees` VALUES ('2002', '10005', 'yaner', '改bug中', '1', 'E:\\qtqq_images\\y2.png', '2');
INSERT INTO `tab_employees` VALUES ('2002', '10006', 'yansan', '写bug中', '1', 'E:\\qtqq_images\\y3.png', '2');
INSERT INTO `tab_employees` VALUES ('2003', '10007', 'shiyi', '以客户要求为主', '1', 'E:\\qtqq_images\\s1.png', '1');
INSERT INTO `tab_employees` VALUES ('2003', '10008', 'shier', '追求市场', '1', 'E:\\qtqq_images\\s2.png', '1');
INSERT INTO `tab_employees` VALUES ('2003', '10009', 'shisan', '紧追市场需求', '1', 'E:\\qtqq_images\\s3.png', '1');
INSERT INTO `tab_employees` VALUES ('2001', '10010', '叶舒华', '少来烦姐哈', '1', 'C:\\Users\\AD\\Pictures\\叶舒华.jpg', null);
